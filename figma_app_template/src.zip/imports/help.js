// Oral AI - Help Center
// Built: 2026-04-07

document.addEventListener('DOMContentLoaded', () => {
    console.log('🦜 Oral AI Help Center initialized');
    
    initFAQToggle();
    initSearch();
});

// FAQ Toggle
function initFAQToggle() {
    const faqItems = document.querySelectorAll('.faq-item');
    
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        
        question.addEventListener('click', () => {
            // Close other open items
            faqItems.forEach(otherItem => {
                if (otherItem !== item && otherItem.classList.contains('active')) {
                    otherItem.classList.remove('active');
                }
            });
            
            // Toggle current item
            item.classList.toggle('active');
        });
    });
    
    // Open first item by default
    if (faqItems.length > 0) {
        faqItems[0].classList.add('active');
    }
}

// Search Functionality
function initSearch() {
    const searchInput = document.querySelector('.search-input');
    const faqItems = document.querySelectorAll('.faq-item');
    const faqCategories = document.querySelectorAll('.faq-category');
    
    if (!searchInput) return;
    
    searchInput.addEventListener('input', (e) => {
        const query = e.target.value.toLowerCase();
        
        if (query.length === 0) {
            // Show all items
            faqItems.forEach(item => item.style.display = '');
            faqCategories.forEach(cat => cat.style.display = '');
            return;
        }
        
        faqCategories.forEach(category => {
            const items = category.querySelectorAll('.faq-item');
            let hasVisibleItems = false;
            
            items.forEach(item => {
                const question = item.querySelector('.faq-question span:nth-child(2)').textContent.toLowerCase();
                const answer = item.querySelector('.faq-answer').textContent.toLowerCase();
                
                if (question.includes(query) || answer.includes(query)) {
                    item.style.display = '';
                    hasVisibleItems = true;
                } else {
                    item.style.display = 'none';
                }
            });
            
            category.style.display = hasVisibleItems ? '' : 'none';
        });
    });
}