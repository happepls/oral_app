// Oral AI - Onboarding
// Built: 2026-04-06

document.addEventListener('DOMContentLoaded', () => {
    console.log('🦜 Oral AI Onboarding initialized');
    
    let currentStep = 0;
    const totalSteps = 4;
    
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    const dots = document.querySelectorAll('.dot');
    const steps = document.querySelectorAll('.step');
    
    // Initialize
    updateUI();
    
    // Previous Button
    if (prevBtn) {
        prevBtn.addEventListener('click', () => {
            if (currentStep > 0) {
                currentStep--;
                updateUI();
            }
        });
    }
    
    // Next Button
    if (nextBtn) {
        nextBtn.addEventListener('click', () => {
            if (currentStep < totalSteps - 1) {
                currentStep++;
                updateUI();
            } else {
                // Complete onboarding
                completeOnboarding();
            }
        });
    }
    
    // Update UI
    function updateUI() {
        // Update dots
        dots.forEach((dot, index) => {
            dot.classList.toggle('active', index === currentStep);
        });
        
        // Update steps
        steps.forEach((step, index) => {
            step.classList.toggle('active', index === currentStep);
        });
        
        // Update buttons
        if (prevBtn) {
            prevBtn.style.visibility = currentStep === 0 ? 'hidden' : 'visible';
        }
        
        if (nextBtn) {
            if (currentStep === totalSteps - 1) {
                nextBtn.textContent = '开始使用 →';
            } else if (currentStep === 0) {
                nextBtn.textContent = '开始';
            } else {
                nextBtn.textContent = '下一步';
            }
        }
    }
    
    // Complete Onboarding
    function completeOnboarding() {
        const level = document.getElementById('levelSelect')?.value || 'intermediate';
        const goal = document.getElementById('goalSelect')?.value || 'study';
        
        // Save preferences (simulated)
        localStorage.setItem('oralAI_onboarding', 'completed');
        localStorage.setItem('oralAI_level', level);
        localStorage.setItem('oralAI_goal', goal);
        
        // Show success toast
        showToast('🎉 欢迎加入 Oral AI！', 'success');
        
        // Simulate navigation to main app
        setTimeout(() => {
            showToast('正在加载主页面...', 'info');
            // In production: window.location.href = 'index.html';
        }, 1500);
    }
    
    // Toast Notification
    function showToast(message, type = 'info') {
        const existingToast = document.querySelector('.toast');
        if (existingToast) existingToast.remove();
        
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.textContent = message;
        toast.style.cssText = `
            position: fixed;
            top: 24px;
            left: 50%;
            transform: translateX(-50%);
            background: ${type === 'success' ? 'var(--color-success)' : type === 'warning' ? 'var(--color-warning)' : 'var(--color-primary)'};
            color: white;
            padding: 12px 24px;
            border-radius: 12px;
            font-weight: 500;
            z-index: 9999;
            animation: slideDown 0.3s ease;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        `;
        
        document.body.appendChild(toast);
        
        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transition = 'opacity 0.3s';
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }
    
    // Add animation keyframes
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateX(-50%) translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(-50%) translateY(0);
            }
        }
    `;
    document.head.appendChild(style);
});